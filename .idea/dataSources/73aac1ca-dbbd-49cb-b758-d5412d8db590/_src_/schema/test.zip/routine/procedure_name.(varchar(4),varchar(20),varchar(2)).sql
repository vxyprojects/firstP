CREATE PROCEDURE `procedure_name`(IN `name` VARCHAR(4), IN `msg` VARCHAR(20), IN `t_status` VARCHAR(2))
  BEGIN
  
     DECLARE err INT DEFAULT '0';
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION  SET err = -1;
     
     START TRANSACTION;
     INSERT INTO t_chat VALUES (name, msg , t_status);     
     INSERT INTO t_chat VALUES (name, msg , t_status);     
     
     
     IF err < 0 THEN
     SELECT err;
     SELECT 'ROLLBAK';
          ROLLBACK;
     ELSE
     SELECT 'COMMIT';
          COMMIT;
     END IF;
  
END